#!/usr/bin/env python3
"""Inventory and extract useful text from a Kaoyan source folder."""

from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


TEXT_EXTENSIONS = {".txt", ".md", ".json", ".csv"}
SKIP_NAMES = {"~$"}
DOWNLOAD_SUFFIXES = {".downloading", ".crdownload", ".tmp"}


def xml_text(data: bytes) -> str:
    root = ET.fromstring(data)
    return "\n".join(node.text or "" for node in root.iter() if node.tag.endswith("}t"))


def docx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        names = [
            name
            for name in archive.namelist()
            if name in {"word/document.xml", "word/footnotes.xml", "word/endnotes.xml"}
        ]
        return "\n".join(xml_text(archive.read(name)) for name in names)


def pptx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        slides = sorted(
            (
                name
                for name in archive.namelist()
                if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)
            ),
            key=lambda name: int(re.search(r"(\d+)", name).group(1)),
        )
        return "\n\n".join(
            f"--- {name} ---\n{xml_text(archive.read(name))}" for name in slides
        )


def pdf_text(path: Path) -> tuple[str, str]:
    try:
        import pypdf  # type: ignore
    except Exception:
        return "", "pdf-text-extraction-unavailable"
    try:
        reader = pypdf.PdfReader(str(path))
        return "\n\n".join(
            f"--- PAGE {index + 1} ---\n{page.extract_text() or ''}"
            for index, page in enumerate(reader.pages)
        ), "ok"
    except Exception as exc:
        return "", f"pdf-error:{type(exc).__name__}"


def extract(path: Path) -> tuple[str, str]:
    suffix = path.suffix.lower()
    try:
        if any(path.name.startswith(prefix) for prefix in SKIP_NAMES):
            return "", "temporary-file"
        if suffix in DOWNLOAD_SUFFIXES or path.name.endswith(tuple(DOWNLOAD_SUFFIXES)):
            return "", "incomplete-download"
        if suffix in TEXT_EXTENSIONS:
            return path.read_text(encoding="utf-8", errors="replace"), "ok"
        if suffix == ".docx":
            return docx_text(path), "ok"
        if suffix == ".pptx":
            return pptx_text(path), "ok"
        if suffix == ".pdf":
            return pdf_text(path)
        if suffix in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}:
            return "", "image-ocr-required"
        return "", "unsupported-format"
    except Exception as exc:
        return "", f"error:{type(exc).__name__}"


def write_markdown(records: list[dict], path: Path) -> None:
    lines = [
        "# Source inventory",
        "",
        f"- Files: {len(records)}",
        f"- Extractable text: {sum(1 for item in records if item['status'] == 'ok')}",
        f"- Need OCR: {sum(1 for item in records if item['status'] == 'image-ocr-required')}",
        f"- Unavailable: {sum(1 for item in records if item['status'] not in {'ok', 'image-ocr-required'})}",
        "",
        "| File | Type | Status | Characters |",
        "|---|---|---|---:|",
    ]
    for item in records:
        lines.append(
            f"| {item['relative_path']} | {item['format']} | {item['status']} | {item['characters']} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--snippet-chars", type=int, default=240)
    args = parser.parse_args()

    root = Path(args.root).resolve()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    records = []

    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        text, status = extract(path)
        relative = str(path.relative_to(root))
        records.append(
            {
                "relative_path": relative,
                "absolute_path": str(path),
                "format": path.suffix.lower().lstrip(".") or "none",
                "bytes": path.stat().st_size,
                "status": status,
                "characters": len(text),
                "snippet": text[: args.snippet_chars],
            }
        )

    (output / "source-inventory.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    write_markdown(records, output / "source-inventory.md")
    print(output / "source-inventory.md")


if __name__ == "__main__":
    main()
