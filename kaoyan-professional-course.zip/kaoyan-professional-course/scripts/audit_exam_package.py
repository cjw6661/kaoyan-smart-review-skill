#!/usr/bin/env python3
"""Audit a generated Kaoyan package for structure and score consistency."""

from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


def docx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        document = archive.read("word/document.xml")
    root = ET.fromstring(document)
    paragraphs = []
    for paragraph in root.iter():
        if paragraph.tag.endswith("}p"):
            value = "".join(
                node.text or "" for node in paragraph.iter() if node.tag.endswith("}t")
            )
            paragraphs.append(value)
    return "\n".join(paragraphs)


def numbered(lines: list[str]) -> list[str]:
    return [line.strip() for line in lines if re.match(r"^\d+\.\s", line.strip())]


def section_count(lines: list[str], start: str, end: str | None) -> int:
    try:
        start_index = lines.index(start) + 1
    except ValueError:
        return -1
    end_index = lines.index(end, start_index) if end and end in lines[start_index:] else len(lines)
    return len(numbered(lines[start_index:end_index]))


def audit_docx(path: Path, forbidden: list[str]) -> dict:
    try:
        text = docx_text(path)
    except Exception as exc:
        return {"file": path.name, "errors": [f"invalid-docx:{type(exc).__name__}"]}

    errors = []
    warnings = []
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if "\ufffd" in text:
        errors.append("replacement-character")
    for placeholder in ("TODO", "[object Object]"):
        if placeholder in text:
            errors.append(f"placeholder:{placeholder}")
    if re.search(r"^\d+\.\s+\d+\.\s", text, flags=re.MULTILINE):
        errors.append("duplicate-question-number")

    for item in forbidden:
        normalized = item.strip()
        if normalized and normalized in text:
            errors.append(f"forbidden-question-type:{normalized}")
    if "单项选择题" in text or re.search(r"^[A-D][\.、]\s", text, flags=re.MULTILINE):
        errors.append("multiple-choice-content")

    fill_count = section_count(lines, "一、填空题", "二、简答题")
    short_count = section_count(lines, "二、简答题", "答案与解析")
    answer_present = "答案" in text
    declared_total = None
    matches = re.findall(r"共\s*(\d+)\s*分", text.replace("\n", " "))
    if matches:
        declared_total = max(int(value) for value in matches)
    normalized = re.sub(r"\s+", "", text)
    if (
        "基础知识简答" in normalized
        and "综合分析与计算" in normalized
        and "50分" in normalized
        and "100分" in normalized
    ):
        declared_total = 150

    if "知识点测试" in path.name:
        if fill_count != 10:
            errors.append(f"expected-10-fill-got-{fill_count}")
        if short_count != 10:
            errors.append(f"expected-10-short-got-{short_count}")
        if not answer_present:
            errors.append("missing-answer-section")
        if declared_total != 150:
            errors.append(f"expected-total-150-got-{declared_total}")

    if "套题" in path.name and ("共 150" not in text and "共150" not in text):
        warnings.append("could-not-confirm-150-point-total")

    return {
        "file": path.name,
        "fill_count": fill_count,
        "short_count": short_count,
        "declared_total": declared_total,
        "answer_present": answer_present,
        "errors": errors,
        "warnings": warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--blueprint")
    parser.add_argument("--output")
    args = parser.parse_args()

    project = Path(args.project).resolve()
    forbidden = ["单项选择题", "独立判断题"]
    expected_total = 150
    if args.blueprint:
        blueprint = json.loads(Path(args.blueprint).read_text(encoding="utf-8"))
        forbidden = blueprint.get("forbidden_question_types", forbidden)
        expected_total = int(blueprint.get("total_score", expected_total))

    reports = []
    for path in sorted(project.rglob("*.docx")):
        if path.name.startswith("~$"):
            reports.append({"file": path.name, "errors": ["temporary-lock-file"]})
            continue
        report = audit_docx(path, forbidden)
        if report.get("declared_total") not in (None, expected_total):
            report.setdefault("errors", []).append(
                f"expected-total-{expected_total}-got-{report['declared_total']}"
            )
        reports.append(report)

    output = Path(args.output).resolve() if args.output else project / "99_audit.json"
    output.write_text(json.dumps(reports, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    errors = [item for item in reports if item.get("errors")]
    print(f"Audited {len(reports)} DOCX files; files with errors: {len(errors)}")
    for item in errors:
        print(f"{item['file']}: {', '.join(item['errors'])}")
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
