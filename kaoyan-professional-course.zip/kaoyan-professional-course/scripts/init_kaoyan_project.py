#!/usr/bin/env python3
"""Create a school-specific Kaoyan project scaffold."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


DIRECTORIES = [
    "01_知识点总结",
    "02_每单元知识点测试",
    "03_每单元套题",
    "04_模拟题",
    "05_答案与评分细则",
    "06_高频简答与公式",
    "07_错题与补弱",
]


def slug(value: str) -> str:
    cleaned = "".join(ch for ch in value if ch not in '\\/:*?"<>|').strip()
    return cleaned or "考研专业课"


def build_manifest(args: argparse.Namespace) -> dict:
    return {
        "school": args.school,
        "department": args.department or "",
        "course_code": args.course_code or "",
        "course_name": args.course,
        "target_year": args.target_year or "",
        "source_root": str(Path(args.source_root).resolve()) if args.source_root else "",
        "output_root": str(Path(args.output_root).resolve()),
        "project_folder": args.project_name,
        "exam": {
            "total_score": args.total_score,
            "duration_minutes": args.duration_minutes,
            "calculator_policy": args.calculator_policy,
            "question_type_policy": args.question_type_policy,
            "forbidden_question_types": [
                item.strip()
                for item in args.forbidden_question_types.split(",")
                if item.strip()
            ],
        },
        "source_priority": [
            "官方考纲/招生目录",
            "目标院校真题/本科卷",
            "目标院校PPT/讲义",
            "指定主教材",
            "辅助教材",
            "预测扩展",
        ],
        "answer_policy": {
            "unit_tests": "inline",
            "unit_sets": "inline",
            "mock_exams": "separate",
        },
        "created_at": datetime.now(timezone.utc).isoformat(),
        "assumptions": [],
        "unresolved_gaps": [],
    }


def build_blueprint(manifest: dict) -> dict:
    total = int(manifest["exam"]["total_score"])
    if total == 150:
        sections = [
            {
                "id": "I",
                "name": "基础知识简答或填空",
                "question_type": "fill_or_short",
                "question_count": 10,
                "points_per_question": 5,
                "total_points": 50,
                "required_answer_elements": ["definition", "formula", "unit"],
                "evidence_sources": [],
            },
            {
                "id": "II",
                "name": "综合分析与计算",
                "question_type": "short_and_calculation",
                "question_count": 10,
                "points_per_question": 10,
                "total_points": 100,
                "required_answer_elements": ["model", "formula", "substitution", "unit", "conclusion"],
                "evidence_sources": [],
            },
        ]
    else:
        sections = [
            {
                "id": "I",
                "name": "待根据院校真题确定",
                "question_type": "fill_or_short",
                "question_count": 10,
                "points_per_question": total / 10,
                "total_points": total,
                "required_answer_elements": ["conclusion", "reason"],
                "evidence_sources": [],
            }
        ]
    return {
        "school": manifest["school"],
        "department": manifest["department"],
        "course_code": manifest["course_code"],
        "course_name": manifest["course_name"],
        "exam_year": manifest["target_year"],
        "total_score": total,
        "duration_minutes": manifest["exam"]["duration_minutes"],
        "calculator_policy": manifest["exam"]["calculator_policy"],
        "source_priority": manifest["source_priority"],
        "forbidden_question_types": manifest["exam"]["forbidden_question_types"],
        "sections": sections,
        "units": [],
        "answer_policy": manifest["answer_policy"],
        "notes": [],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--school", required=True)
    parser.add_argument("--course", required=True)
    parser.add_argument("--course-code", default="")
    parser.add_argument("--department", default="")
    parser.add_argument("--target-year", default="")
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--project-name", default="")
    parser.add_argument("--total-score", type=int, default=150)
    parser.add_argument("--duration-minutes", type=int, default=150)
    parser.add_argument("--calculator-policy", default="不允许使用计算器")
    parser.add_argument(
        "--question-type-policy",
        default="默认无选择题，以填空、简答和综合计算为主",
    )
    parser.add_argument(
        "--forbidden-question-types",
        default="单项选择题,独立判断题",
    )
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    args.project_name = args.project_name or f"{slug(args.school)}{slug(args.course)} - codex"
    project = Path(args.output_root).resolve() / args.project_name
    if project.exists() and not args.force:
        raise SystemExit(f"Project already exists: {project}. Use --force to update metadata.")

    for directory in DIRECTORIES:
        (project / directory).mkdir(parents=True, exist_ok=True)

    manifest = build_manifest(args)
    blueprint = build_blueprint(manifest)
    (project / "project-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (project / "exam-blueprint.json").write_text(
        json.dumps(blueprint, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (project / "source-inventory.md").write_text(
        "# Source inventory\n\nRun `scripts/inventory_sources.py` to populate this file.\n",
        encoding="utf-8",
    )
    (project / "00_考情与总目录.md").write_text(
        "\n".join(
            [
                f"# {manifest['school']} {manifest['course_name']} 考情与总目录",
                "",
                f"- 专业课代码：{manifest['course_code']}",
                f"- 总分：{manifest['exam']['total_score']}",
                f"- 时长：{manifest['exam']['duration_minutes']} 分钟",
                f"- 计算器：{manifest['exam']['calculator_policy']}",
                f"- 来源根目录：{manifest['source_root']}",
                "",
                "## 待补充",
                "",
                "- 官方考纲与题型",
                "- 主教材与辅助教材",
                "- 真题与高频模型",
                "- 单元划分与分值",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(project)


if __name__ == "__main__":
    main()
