#!/usr/bin/env python3
"""Validate a Kaoyan exam blueprint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


REQUIRED_TOP = {
    "school",
    "course_name",
    "total_score",
    "duration_minutes",
    "sections",
    "units",
}


def validate(data: dict) -> tuple[list[str], list[str]]:
    errors = []
    warnings = []
    missing = sorted(REQUIRED_TOP - data.keys())
    if missing:
        errors.append(f"Missing top-level fields: {', '.join(missing)}")

    try:
        total = int(data["total_score"])
    except Exception:
        total = -1
        errors.append("total_score must be a positive integer")

    sections = data.get("sections", [])
    if not sections:
        errors.append("At least one section is required")
    section_total = 0
    section_ids = set()
    for index, section in enumerate(sections, 1):
        section_id = str(section.get("id", "")).strip()
        if not section_id:
            errors.append(f"Section {index} has no id")
        elif section_id in section_ids:
            errors.append(f"Duplicate section id: {section_id}")
        section_ids.add(section_id)
        try:
            points = int(section["total_points"])
        except Exception:
            errors.append(f"Section {section_id or index} has invalid total_points")
            continue
        section_total += points
        count = section.get("question_count")
        per_question = section.get("points_per_question")
        if count is not None and per_question is not None:
            expected = float(count) * float(per_question)
            if abs(expected - points) > 1e-6:
                errors.append(
                    f"Section {section_id}: {count} × {per_question} != {points}"
                )

    if total >= 0 and section_total != total:
        errors.append(f"Section points sum to {section_total}, expected {total}")

    units = data.get("units", [])
    unit_ids = set()
    for index, unit in enumerate(units, 1):
        unit_id = str(unit.get("id", "")).strip()
        if not unit_id:
            errors.append(f"Unit {index} has no id")
        elif unit_id in unit_ids:
            errors.append(f"Duplicate unit id: {unit_id}")
        unit_ids.add(unit_id)
        links = unit.get("linked_sections", [])
        for link in links:
            if link not in section_ids:
                errors.append(f"Unit {unit_id} links unknown section: {link}")

    if not units:
        warnings.append("No units are defined; chapter coverage cannot be checked")
    if int(data.get("duration_minutes", 0) or 0) <= 0:
        errors.append("duration_minutes must be positive")
    if not data.get("forbidden_question_types"):
        warnings.append("forbidden_question_types is empty")
    return errors, warnings


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("blueprint")
    args = parser.parse_args()
    path = Path(args.blueprint).resolve()
    data = json.loads(path.read_text(encoding="utf-8"))
    errors, warnings = validate(data)
    for warning in warnings:
        print(f"WARNING: {warning}")
    for error in errors:
        print(f"ERROR: {error}")
    if errors:
        raise SystemExit(1)
    print(f"OK: {path}")


if __name__ == "__main__":
    main()
