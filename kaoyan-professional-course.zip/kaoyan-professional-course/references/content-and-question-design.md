# Content and Question Design

## Knowledge summary design

For each chapter, write in this order:

1. why the chapter matters and how it appears in target-school papers
2. definitions that should be reproduced closely
3. system composition or block diagram
4. governing formulas, symbol definitions, units, and assumptions
5. measurement circuits and operating modes
6. error sources and corrective measures
7. primary-book versus secondary-book comparison
8. target-school high-frequency models
9. common traps
10. worked example or exam-style variant

The summary should let a student answer a full paper prompt without inferring a missing intermediate step.

## Question generation sequence

Generate in this order:

1. official or observed question
2. textbook example or exercise adaptation
3. same-model numerical variant
4. same-concept different-application variant
5. cross-chapter comprehensive variant
6. labeled prediction extension

Do not start with predictions. Predictions should be a controlled extension of repeated target-school patterns.

## No-choice conversion

When choices are forbidden:

- convert factual discriminations into fill-in-the-blank
- convert definitions and explanations into short answer
- convert numerical choices into calculation questions
- convert yes/no statements into “判断并说明理由” only when a judgment answer is useful
- remove all `A. B. C. D.` options and all answer letters

The final paper should still cover the same knowledge points after conversion.

## Numerical QA

For every calculation:

- list known quantities and units
- write the original formula before substituting
- convert mm, cm, μm, pF, nA, mV, and degrees consistently
- state whether an approximation assumes small displacement or small strain
- check order of subtraction for reference values and coordinate systems
- include direction or sign when the physical quantity is signed
- verify the result is plausible for the range

For optical and electrical values, check:

- `NA=sqrt(n1²-n2²)` is dimensionless and `sinθmax≤1`
- angles in `B≈W/θ` are radians
- PSD current ratios use `I0=I1+I2`
- Hall carrier density uses thickness in metres
- piezoelectric sensitivity products retain reciprocal units
- thermocouple correction adds `E(T0,0)` before table lookup

## Answer and scoring design

Every answer should contain:

- the direct conclusion
- the required definition or formula
- a short derivation or explanation
- units and sign
- scoring points for partial credit

For long answers, format the scoring rubric as:

```text
结论：1分
公式：2分
代入与单位：2分
最终结果：1分
```

Do not expose hidden assumptions only in the answer. If an assumption is needed to solve the question, state it in the stem or explicitly allow a reasonable assumption.

## Source tags

Use a compact tag at the end of each question or answer:

```text
【官方考纲】【目标院校真题】【主教材改编】【预测扩展】
```

Do not label every sentence. Tag the question or the answer source block.
