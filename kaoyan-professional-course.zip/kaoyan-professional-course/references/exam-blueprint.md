# Exam Blueprint and Score Design

## Purpose

Convert syllabus and past-paper evidence into a machine-checkable blueprint before writing questions. The blueprint prevents silent drift in total score, section weight, question types, and expected answer depth.

## Blueprint fields

Use the JSON template in `assets/exam-blueprint.template.json`:

- school
- department
- course_code
- course_name
- exam_year
- total_score
- duration_minutes
- calculator_policy
- source_priority
- forbidden_question_types
- sections
- units
- answer_policy
- notes

Each section contains:

- id
- name
- question_type
- question_count
- points_per_question
- total_points
- required_answer_elements
- evidence_sources

Each unit contains:

- id
- name
- chapter_source
- weight
- must_know
- high_frequency_models
- linked_sections

## Default score models

### When the target school's paper is known

Copy the observed structure exactly. Do not impose the defaults below.

### 150-point full paper with no official structure

Use:

```text
一、基础知识简答或填空：50分
二、综合分析与计算：100分
```

For a no-choice unit test:

```text
一、填空题：10题×5分=50分
二、简答与计算：10题×10分=100分
```

For a unit paper:

```text
一、填空题：5题×10分=50分
二、简答题：6题×5分=30分
三、综合分析与计算：4题合计50分
四、附加押题：1题20分
```

The add-on section is optional but must still count toward the declared total when included.

## Section design rules

### Fill-in questions

Use atomic, unambiguous answers. Prefer one or two blanks per stem. A long sentence may be acceptable when it tests a single definition, but avoid turning fill-in questions into disguised essays.

### Short-answer questions

Require a definition, mechanism, comparison, condition, or list of measures. Include the expected scoring vocabulary in the answer key.

### Calculation questions

Require a model, formula, substitution, unit, and conclusion. Reuse the target school's common numerical patterns and avoid irrelevant arithmetic.

### Comprehensive questions

Combine at least two knowledge points, such as sensor plus circuit, law plus numerical correction, or optical geometry plus current division. These questions should carry the highest discrimination.

## Point arithmetic

Before saving the blueprint:

- `sum(section.total_points) == total_score`
- `question_count × points_per_question == total_points` when uniform
- each unit maps to at least one full-paper section
- extension points do not make a paper exceed its total
- all unit tests use the same full-paper total as the course

Run:

```bash
python scripts/validate_blueprint.py <blueprint.json>
```

## Score rescaling rule

If an earlier draft uses 100 points for a 150-point course:

1. preserve the question content
2. increase fill points from 4 to 5
3. increase short/calculation points from 7.5 to 10
4. add questions until there are 10 fill and 10 short/calculation questions
5. rerender every affected document

Do not merely relabel the total. The section totals and answer count must change with it.
