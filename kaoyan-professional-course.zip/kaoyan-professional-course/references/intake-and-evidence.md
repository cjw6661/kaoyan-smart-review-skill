# Intake and Evidence

## Purpose

Capture enough school-specific information to prevent generic tutoring from replacing the target school's actual exam. The agent should infer fields from the source folder whenever possible and list unresolved assumptions rather than stopping for routine confirmation.

## Full intake form

```text
目标院校：
院系/专业：
专业课代码与名称：
考试年份/目标年份：
资料根目录：
输出根目录：
输出文件夹名：
官方考纲或招生目录：
参考书目（主教材）：
参考书目（辅助教材）：
本校PPT/讲义：
历年真题：
本科卷/期末卷/样题：
老师强调或课堂录音：
试卷满分：
考试时间：
是否允许计算器：
题型与各题分值：
禁止出现的题型：
每题是否必须标来源：
需要交付：
押题扩展强度：
知识总结侧重：
计算题侧重：
需要双书对照：
其他限制：
```

## Source priority

Use evidence in this order when scope, wording, or question style conflict:

1. 官方考纲、招生目录、考试说明、官方样卷
2. 目标院校近年真题、本科卷、期末卷
3. 目标院校本校 PPT、课程讲义、老师明确强调内容
4. 目标院校指定主教材及其课后题
5. 辅助教材、另一版本教材及其课后题
6. 通用学科知识、公开课、其他院校题目
7. 基于重复题型的预测扩展

The primary source controls definitions and chapter order. The secondary source controls derivation, comparison, and additional practice. Do not silently replace a school-specific definition with a more general textbook definition.

## Evidence labels

Use these labels consistently:

- `官方考纲`
- `目标院校真题`
- `目标院校本科卷`
- `本校PPT`
- `主教材原文/改编`
- `辅助教材补充`
- `通用知识`
- `预测扩展`

Example source line:

```text
命题依据：北理2026真题；主教材第7章；通过PSD三角测距模型扩展
```

## Source inventory checklist

For each source record:

- exact path and format
- whether text is extractable or image-only
- chapter coverage
- whether it is official, school-authored, textbook, or third-party
- high-confidence facts
- uncertain OCR lines
- page or slide references
- source conflicts
- whether the file is incomplete or only a download placeholder

Do not treat `.baiduyun.p.downloading`, zero-byte files, or incomplete videos as usable evidence. Note them as unavailable.

## Conflict handling

When two books use different notation:

1. keep the primary-book notation in the main answer
2. show the equivalent secondary-book formula separately
3. note the conversion if it affects a numerical answer
4. never merge incompatible definitions into one sentence

When a past paper and a textbook disagree on a convention, the school paper controls the expected answer for that course.

## Missing-information policy

Proceed with clearly labeled assumptions when the missing field is minor. Ask the user only when one of these is missing and cannot be inferred:

- target school
- professional course or course code
- source folder
- official total score when the requested artifact is a full paper
- required output format

Record every assumption in `00_考情与总目录.docx` and the final response.
