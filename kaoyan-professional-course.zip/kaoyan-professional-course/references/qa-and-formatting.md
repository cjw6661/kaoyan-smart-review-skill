# QA and Formatting

## Document structure

Use clear, exam-oriented titles:

```text
第00单元 知识点测试
第00单元 套题
目标院校专业课模拟题一
目标院校专业课模拟题一 答案与评分细则
```

Every paper starts with:

- school and course code
- exam title
- total score
- duration
- calculator policy
- section score table

Every answer document starts with a matching title and identifies the paper it belongs to.

## Typography and layout

- Use A4 portrait unless the source paper requires another size.
- Keep margins wide enough for handwriting and annotations.
- Use black Title and Heading styles.
- Use tables only for score structures, comparisons, formula summaries, and scoring rubrics.
- Keep formulas as text or native equations that render reliably.
- Do not use decorative cards or one-note color palettes.
- Ensure table cells wrap instead of clipping.
- Keep question numbers and answer numbers identical.

## Automated checks

Run the package auditor:

```bash
python scripts/audit_exam_package.py <project-folder> --blueprint <blueprint.json>
```

The auditor checks:

- DOCX files open as valid OOXML packages
- no `TODO`, `[object Object]`, replacement characters, or duplicated numbers
- no forbidden `单项选择题` section when the blueprint forbids it
- fill and short-answer counts
- declared point sums where they can be extracted
- answer-section presence for unit tests and unit sets

## Render checks

Use the `documents` skill for DOCX creation and rendering. Render changed documents to PDF and page images. Inspect every page for:

- blank pages
- clipped table text
- overlapping blocks
- missing glyphs
- orphaned headings
- answer pages separated from their question paper
- page-number/footer problems

If a page contains a broken table, repair the table width or grid instead of shrinking the font below readable size.

## Final report

Write `99_资料审计报告.md` with:

- source files read
- source files skipped and why
- official total score and time
- question-type policy
- point totals per paper
- missing/unresolved evidence
- changes made during QA
- remaining risks

Keep QA artifacts in the project folder only when they help the user verify the result. Do not deliver temporary render images unless requested.
