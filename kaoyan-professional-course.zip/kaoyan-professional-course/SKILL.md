---
name: kaoyan-professional-course
description: Build, revise, and audit school-specific Chinese postgraduate entrance exam packages for a named university, professional course, course code, and source archive. Use whenever the user mentions 考研专业课, 目标院校, 自命题, 专业课代码, 院校真题, 本科卷, 考纲, 参考书, 本校PPT, 知识点总结, 单元测试, 单元套题, 模拟卷, 高频考点, 押题扩展, 答案与评分细则, or asks to produce study materials that must follow a target school's exam style. The skill must prioritize school-specific evidence, preserve the official score/time/type structure, distinguish observed questions from predictions, validate totals and answers, and produce render-checked DOCX or the requested format.
---

# 考研专业课资料生成

Turn a user's target-school folder into a complete, school-specific exam package. The key value is not generic subject tutoring; it is extracting the target school's actual scope, question shape, scoring, source hierarchy, and repeated calculation models, then building materials that let the user practice in that exact format.

## Non-negotiable principles

1. **School evidence outranks generic knowledge.** Use the priority order in [references/intake-and-evidence.md](references/intake-and-evidence.md). When sources disagree, prefer the official syllabus and target-school papers/PPT for answer wording and exam scope. Use textbooks to complete theory and calculations.
2. **Never fabricate provenance.** Label each question or claim as `官方考纲`, `目标院校真题/本科卷`, `本校PPT`, `主教材改编`, `辅助教材补充`, or `预测扩展`. Never call a prediction an original paper question.
3. **Match the real exam blueprint.** Confirm the total score, duration, calculator policy, question types, section scores, and answer expectations. The default score is the target school's published total; if unavailable but a full paper is 150 points, all full papers and unit tests must be 150 points. Never let section totals drift silently.
4. **Respect the user's question-type preference.** For this user's recurring exam-material workflow, omit multiple-choice and standalone yes/no sections unless the target-school official paper or the user explicitly requires them. Convert useful choice facts into fill-in-the-blank or short-answer questions. Keep short-answer, fill-in, analysis, and calculation questions as the default.
5. **Do not pad with generic fluff.** Every extra page must help recall, calculation, discrimination, or exam execution. Prefer dense knowledge maps, formulas, misconception checks, worked examples, scoring rubrics, and repeated calculation patterns.
6. **Validate the artifacts, not only the prose.** Count questions, sum points, match question numbers to answers, check forbidden question types, render DOCX to PDF/PNG when the document toolchain is available, and inspect for blank pages, clipping, broken tables, repeated numbers, and missing answer keys.

## Required input

Extract as much as possible from the supplied folder first. Ask only for information that materially changes the output and cannot be inferred. Use the full intake form from [references/intake-and-evidence.md](references/intake-and-evidence.md).

Minimum useful input:

- 目标院校
- 院系/专业
- 专业课代码与名称
- 资料根目录
- 官方考纲或招生目录路径
- 参考书目及主教材
- 真题/本科卷/样题/本校PPT路径（如有）
- 试卷满分、时长、计算器规则
- 题型与分值
- 输出根目录和交付格式

Defaults when the user has not specified them:

- Output folder: `<院校><专业课简称> - codex`
- Primary source: the book explicitly named by the target school or the book used in its PPT
- Secondary source: another named reference book, used for derivation and extra practice
- Full-paper score: official score if known; otherwise 150 if the source materials show a 150-point paper
- Full-paper structure: replicate the observed paper; if unknown, use `基础填空/简答 50 分 + 综合分析与计算 100 分`
- Unit tests: fill 50 + short/calculation 100 for a 150-point course
- Unit sets: fill 50 + short 30 + calculation 50 + extension 20
- Answer placement: unit tests and unit sets include answers at the end; mock exams have separate answer/scoring documents

## Workflow

### 1. Build the intake and source manifest

Create `<project>/00_考情与总目录.docx` and a machine-readable project manifest. Record:

- school, department, course code/name, exam year, target year
- source priority and exact file paths
- score/time/calculator/type constraints
- output folder and naming convention
- question policy, including forbidden types
- assumptions and unresolved gaps

Use [assets/manifest.template.json](assets/manifest.template.json). Run `scripts/init_kaoyan_project.py` to scaffold the project and `scripts/inventory_sources.py` to inventory the source files.

### 2. Audit the target school

Inspect the official syllabus first, then the target school's past papers, undergraduate papers, PPT, teacher notes, textbook, and secondary exercises. Separate:

- explicitly required knowledge
- recurring question forms and score weight
- repeated calculation or derivation models
- definitions and wording that should be copied into standard answers
- source-level differences that affect the answer
- topics that are theoretically important but not likely to be tested

Read [references/exam-blueprint.md](references/exam-blueprint.md) before designing the paper structure. Write the result as an exam blueprint JSON using [assets/exam-blueprint.template.json](assets/exam-blueprint.template.json).

### 3. Build the knowledge architecture

Create one main knowledge summary with chapters in the target school's teaching order. For each chapter include:

- chapter position in the syllabus and score weight
- mandatory definitions and system diagrams
- formulas with symbols, units, assumptions, and common algebra traps
- target-school emphasis and previous question forms
- primary-book answer and secondary-book comparison where useful
- worked examples and exam-style variants
- common misconceptions and scoring points

Do not split the summary into disconnected cards. Keep a coherent chapter narrative so the user can answer a full prompt without missing intermediate steps.

### 4. Design the question bank

For every unit, create:

1. knowledge-point test
2. unit paper
3. answer/scoring document or answer section

For every full paper, create the exact observed section structure and total score. Use realistic numbers, units, and diagrams where the target-school paper uses them. Keep the source tag on every synthetic question and every predicted extension.

Read [references/content-and-question-design.md](references/content-and-question-design.md) for the question-generation rules and calculation checks. If the user requests no multiple-choice questions, do not leave choices in any study pack.

### 5. Generate and verify DOCX

Use the `documents` skill for `.docx` creation and rendering. Use the `pdf`, `pptx`, or `spreadsheets` skill only when those are the actual source or output formats. For existing source documents, extract text and embedded images before editing.

Before delivery:

- validate the blueprint with `scripts/validate_blueprint.py`
- audit the generated package with `scripts/audit_exam_package.py`
- render changed DOCX files and inspect all page images or a deterministic PDF page check
- confirm each paper's points sum to its declared total
- confirm each question has an answer and scoring point
- confirm no multiple-choice section remains when forbidden
- confirm no placeholders such as `TODO`, `[object Object]`, repeated numbering, blank pages, or orphan answers remain

### 6. Deliver

Place the final materials in the requested folder and provide an index. Return the folder and the highest-value entry files, not every internal QA artifact. State:

- official/source-confirmed facts
- inferred assumptions
- prediction extensions
- any source that could not be read
- exact validation performed

## Output structure

Use this default unless the user asks otherwise:

```text
<院校><专业课> - codex/
├── 00_考情与总目录.docx
├── 01_知识点总结/
├── 02_每单元知识点测试/
├── 03_每单元套题/
├── 04_模拟题/
├── 05_答案与评分细则/
├── 06_高频简答与公式/
├── 07_错题与补弱/
└── 99_资料审计报告.md
```

Keep filenames stable and sortable. Include the unit number, unit name, and artifact type in each filename. Put answers in separate files for mock exams; include them at the end for unit-level practice unless the user wants a separate answer booklet.

## Adaptive rules

- If the target-school paper uses a different type distribution, follow the paper over the generic default.
- If the user asks for only one artifact, generate only that artifact but still build the source and score manifest internally.
- If a source is a scanned image, use OCR and mark uncertain readings; never invent missing symbols or numbers.
- If the target school uses multiple textbooks, make the school-designated book the main line and use the other as a comparison/expansion layer.
- If a full paper is 150 points but a unit test was earlier drafted as 100, rescale all sections and add questions until the total is exactly 150.
- If a paper contains a calculator prohibition, avoid questions requiring non-elementary arithmetic and show all intermediate values.

## Supporting resources

- Intake, evidence hierarchy, and source inventory: [references/intake-and-evidence.md](references/intake-and-evidence.md)
- Exam blueprint and score design: [references/exam-blueprint.md](references/exam-blueprint.md)
- Question design and calculation QA: [references/content-and-question-design.md](references/content-and-question-design.md)
- Formatting and final validation: [references/qa-and-formatting.md](references/qa-and-formatting.md)
- Scaffold helper: [scripts/init_kaoyan_project.py](scripts/init_kaoyan_project.py)
- Source inventory helper: [scripts/inventory_sources.py](scripts/inventory_sources.py)
- Blueprint validator: [scripts/validate_blueprint.py](scripts/validate_blueprint.py)
- Package auditor: [scripts/audit_exam_package.py](scripts/audit_exam_package.py)
